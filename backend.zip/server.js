import express from 'express';
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import { jsPDF } from 'jspdf';
import { fileURLToPath } from 'url';

// Handle __dirname and __filename for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB Connection
mongoose.connect('mongodb://localhost:27017/auth_db', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

// User Schema
const userSchema = new mongoose.Schema({
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
});

const User = mongoose.model('User', userSchema);

// Feedback Schema
const feedbackSchema = new mongoose.Schema({
    name: { type: String, required: true },
    userEmail: { type: String, required: true },
    message: { type: String, required: true },
    rating: { type: Number, required: true, min: 1, max: 5 },
    createdAt: { type: Date, default: Date.now }
}, { 
    collection: 'feedbacks'  // Explicitly name the collection
});

const Feedback = mongoose.model('Feedback', feedbackSchema);

// Register Route
app.post('/api/register', async (req, res) => {
    try {
        const { email, password } = req.body;

        // Check if user already exists
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: 'User already exists' });
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Create new user
        const user = new User({
            email,
            password: hashedPassword,
        });

        await user.save();
        res.status(201).json({ message: 'User registered successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
});

// Login Route
app.post('/api/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        // Find user
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(400).json({ message: 'Invalid credentials' });
        }

        // Check password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ message: 'Invalid credentials' });
        }

        res.json({ message: 'Login successful' });
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
});

// Feedback Submission Route
app.post('/api/feedbacks', async (req, res) => {
    try {
        const { name, userEmail, message, rating } = req.body;

        // Create new feedback
        const feedback = new Feedback({
            name,
            userEmail,
            message,
            rating
        });

        // Save feedback to database
        await feedback.save();

        res.status(201).json({ 
            message: 'Feedback submitted successfully',
            feedback: feedback 
        });
    } catch (error) {
        console.error('Feedback submission error:', error);
        res.status(500).json({ 
            message: 'Error submitting feedback', 
            error: error.message 
        });
    }
});

// Palette and Report Generation Route
app.post('/api/palette/generate', (req, res) => {
    const { eyeColor, hairColor, skinColor, context } = req.body;

    const undertone = determineUndertone(skinColor);
    const palette = generatePalette(eyeColor, hairColor, skinColor, undertone, context);

    const pdfPath = generatePDFReport(palette, undertone, context);

    res.status(200).json({
        palette,
        pdfLink: `http://localhost:5000/reports/${path.basename(pdfPath)}`,
    });
});

function determineUndertone(skinColor) {
    return skinColor.toLowerCase().includes('warm') ? 'Warm' : 'Cool';
}

function generatePalette(eyeColor, hairColor, skinColor, undertone, context) {
    const colors = undertone === 'Warm'
        ? ['#FF5733', '#FFC300', '#DAF7A6']
        : ['#5DADE2', '#AED6F1', '#D2B4DE'];

    return {
        colors: colors.map(color => adjustForContext(color, context)),
        undertone,
        context,
    };
}

function adjustForContext(color, context) {
    if (context === 'formal') {
        return darkenColor(color);
    } else if (context === 'seasonal') {
        return lightenColor(color);
    }
    return color;
}

function darkenColor(color) {
    return color; // Add logic to darken the color
}

function lightenColor(color) {
    return color; // Add logic to lighten the color
}

function generatePDFReport(palette, undertone, context) {
    const doc = new jsPDF();

    doc.setFont('Helvetica', 'bold');
    doc.text('Color Analysis Report', 20, 20);

    doc.setFont('Helvetica', 'normal');
    doc.text(`Context: ${context}`, 20, 30);
    doc.text(`Undertone: ${undertone}`, 20, 40);

    palette.colors.forEach((color, index) => {
        doc.setFillColor(color);
        doc.rect(20, 50 + index * 10, 10, 10, 'F');
    });

    const reportsDir = path.join(__dirname, 'reports');
    if (!fs.existsSync(reportsDir)) {
        fs.mkdirSync(reportsDir);
    }

    const filePath = path.join(reportsDir, `report-${Date.now()}.pdf`);
    doc.save(filePath);

    return filePath;
}

// Serve static files for reports
app.use('/reports', express.static(path.join(__dirname, 'reports')));

// Start Server
const PORT = 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));