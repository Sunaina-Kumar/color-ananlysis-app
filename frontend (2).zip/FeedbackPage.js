import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './FeedbackPage.css';

const FeedbackPage = () => {
  const [name, setName] = useState('');
  const [message, setMessage] = useState('');
  const [rating, setRating] = useState(0);
  const [submitMessage, setSubmitMessage] = useState('');

  const navigate = useNavigate();

  // Placeholder for user email, replace with actual logged-in user's email
  const userEmail = 'user@example.com';

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:5000/api/feedbacks', {
        name,
        userEmail,
        message,
        rating,
      });
      setName('');
      setMessage('');
      setRating(0);
      setSubmitMessage('Feedback submitted successfully!');
      console.log('Server Response:', response.data); // Debug log
    } catch (error) {
      console.error('Error submitting feedback:', error.response?.data || error.message);
      setSubmitMessage('Failed to submit feedback. Please try again.');
    }
  };

  const handleHomeNavigation = () => {
    navigate('/home');
  };

  const handleAboutNavigation = () => {
    navigate('/about');
  };

  return (
    <div className="App">
      <header>
        <div className="logo">HueHub</div>
        <nav className="navbar">
          <ul className="nav-links">
            <li>
              <a onClick={handleHomeNavigation} className="nav-link" style={{ cursor: 'pointer' }}>
                Home
              </a>
            </li>
            <li>
              <a onClick={handleAboutNavigation} className="nav-link" style={{ cursor: 'pointer' }}>
                About Us
              </a>
            </li>
            <li>
              <a href="#feedback" className="nav-link">Feedback</a>
            </li>
          </ul>
        </nav>
      </header>

      <div className="feedback-container">
        <form onSubmit={handleSubmit} className="feedback-form">
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Your Name"
            required
            className="feedback-input"
          />
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Your Feedback"
            required
            className="feedback-input"
          />

          <div className="star-rating">
            {[...Array(5)].map((_, index) => (
              <span
                key={index}
                className={`star ${rating >= index + 1 ? 'filled' : ''}`}
                onClick={() => setRating(index + 1)}
              >
                ★
              </span>
            ))}
          </div>

          <button type="submit" className="submit-button">Submit Feedback</button>
        </form>

        {submitMessage && <p className="submit-message">{submitMessage}</p>}
      </div>

      <footer>
        <div className="container">
          <h5>HueHub © 2024. All Rights Reserved.</h5>
        </div>
      </footer>
    </div>
  );
};

export default FeedbackPage;
