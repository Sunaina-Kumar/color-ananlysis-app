

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './home.css';
import analyzeColors from './colorAnalysis.js';

const Home = () => {
  const [uploadedImage, setUploadedImage] = useState(null);
  const [eyeColor, setEyeColor] = useState('');
  const [hairColor, setHairColor] = useState('');
  const [skinColor, setSkinColor] = useState('');
  const [magnifierStyle, setMagnifierStyle] = useState({});
  const [currentPicker, setCurrentPicker] = useState(null);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [outputHTML, setOutputHTML] = useState(''); // New state for output

  const navigate = useNavigate();

  const getColorAtPosition = (event) => {
    if (!currentPicker) return;

    const img = document.getElementById('uploadedImage');
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    
    canvas.width = img.naturalWidth;
    canvas.height = img.naturalHeight;
    context.drawImage(img, 0, 0);

    const rect = img.getBoundingClientRect();
    const x = (event.clientX - rect.left) * (img.naturalWidth / img.width);
    const y = (event.clientY - rect.top) * (img.naturalHeight / img.height);
    
    const pixel = context.getImageData(x, y, 1, 1).data;
    const hex = '#' + ((1 << 24) + (pixel[0] << 16) + (pixel[1] << 8) + pixel[2]).toString(16).slice(1);
    
    handleColorPick(hex, currentPicker.setter);
  };

  const handleImageUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setUploadedImage(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleColorPick = (color, setter) => {
    setter(color);
    deactivateDropper();
  };

  const activateDropper = (picker, setter) => {
    if (!uploadedImage) {
      alert('Please upload an image first');
      return;
    }
    setCurrentPicker({ picker, setter });
  };

  const deactivateDropper = () => {
    setCurrentPicker(null);
    setMagnifierStyle({ display: 'none' });
  };

  const moveMagnifier = (event) => {
    if (!currentPicker) return;

    const img = document.getElementById('uploadedImage');
    const rect = img.getBoundingClientRect();
    const magnifyOffset = 20;

    setMagnifierStyle({
      display: 'block',
      left: `${event.clientX + magnifyOffset}px`,
      top: `${event.clientY + magnifyOffset}px`,
      width: '200px',
      height: '200px',
      border: '2px solid #000',
      borderRadius: '50%',
      overflow: 'hidden',
      pointerEvents: 'none',
      zIndex: '1000',
      boxShadow: '0 0 10px rgba(0, 0, 0, 0.5)',
      backgroundImage: `url(${uploadedImage})`,
      backgroundPosition: `-${(event.clientX - rect.left) * 2}px -${(event.clientY - rect.top) * 2}px`,
      backgroundSize: `${img.width * 2}px ${img.height * 2}px`,
    });
  };

  const handleAnalyze = () => {
    if (!eyeColor || !hairColor || !skinColor) {
      alert('Please pick all colors before analyzing');
      return;
    }

    try {
      const result = analyzeColors(eyeColor, hairColor, skinColor);
      setAnalysisResult(result);

      // Generate HTML using React-friendly approach
      const analysisHTML = `
        <div class="analysis-container" style="text-align: left; padding: 20px;">
          <div class="analysis-header" style="margin-bottom: 30px;">
            <h3 style="margin-bottom: 15px;">Analysis Results</h3>
            <p>Season: ${result.season}</p>
            <p>Undertone: ${result.undertone}</p>
            <p>${result.description}</p>
          </div>
          
          <div class="results-section" style="margin-bottom: 30px;">
            <h4 style="margin-bottom: 20px;">Colors That Suit You</h4>
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(80px, 1fr)); gap: 20px; margin-bottom: 30px;">
              ${result.details.suitableColors.map(color => `
                <div style="text-align: center;">
                  <div style="width: 80px; height: 80px; background-color: ${color.hex}; margin-bottom: 8px; border-radius: 8px;"></div>
                  <span style="font-size: 14px;">${color.name}</span>
                </div>
              `).join('')}
            </div>

            <h4 style="margin-bottom: 20px;">Colors to Avoid</h4>
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(80px, 1fr)); gap: 20px; margin-bottom: 30px;">
              ${result.details.avoidColors.map(color => `
                <div style="text-align: center;">
                  <div style="width: 80px; height: 80px; background-color: ${color.hex}; margin-bottom: 8px; border-radius: 8px;"></div>
                  <span style="font-size: 14px;">${color.name}</span>
                </div>
              `).join('')}
            </div>

            <h4 style="margin-bottom: 20px;">Jewelry Recommendations</h4>
            <ul style="list-style-position: inside; padding-left: 0;">
              ${result.details.jewelry.map(item => `
                <li style="margin-bottom: 8px;">${item}</li>
              `).join('')}
            </ul>
          </div>
        </div>
      `;

      // Set the generated HTML to state
      setOutputHTML(analysisHTML);
    } catch (error) {
      console.error('Error during analysis:', error);
      alert('Error: Analysis failed. Please try again.');
    }
  };

  const handleAboutNavigation = () => {
    navigate('/about');
  };

  // Add this near the other handler at the top of the Home component
const handleFeedbackNavigation = () => {
  navigate('/feedback');
};

// Then update the feedback link in the nav-links:

  return (
    <div className="App">
      <header>
        <div className="logo">HueHub</div>
        <nav className="navbar">
          <ul className="nav-links">
            <li><a href="#home" className="nav-link">Home</a></li>
            <li><a onClick={handleAboutNavigation} className="nav-link" style={{cursor: 'pointer'}}>About Us</a></li>
            <li><a onClick={handleFeedbackNavigation} className="nav-link" style={{cursor: 'pointer'}}>Feedback</a></li>
            </ul>
        </nav>
      </header>

      <div className="container">
        <input type="file" onChange={handleImageUpload} accept="image/*" />
        
        {uploadedImage && (
          <img
            id="uploadedImage"
            src={uploadedImage}
            alt="Uploaded"
            onClick={getColorAtPosition}
            onMouseMove={moveMagnifier}
            onMouseLeave={deactivateDropper}
          />
        )}

        <div className="color-picker">
          <div>
            <label>Eye Color</label>
            <div className="color-display" style={{ backgroundColor: eyeColor }}></div>
            <button onClick={() => activateDropper('eye', setEyeColor)}>Pick Eye Color</button>
          </div>
          
          <div>
            <label>Hair Color</label>
            <div className="color-display" style={{ backgroundColor: hairColor }}></div>
            <button onClick={() => activateDropper('hair', setHairColor)}>Pick Hair Color</button>
          </div>
          
          <div>
            <label>Skin Color</label>
            <div className="color-display" style={{ backgroundColor: skinColor }}></div>
            <button onClick={() => activateDropper('skin', setSkinColor)}>Pick Skin Color</button>
          </div>
        </div>

        <button id="analyzeButton" onClick={handleAnalyze}>Analyze Palette</button>

        {/* Render output using dangerouslySetInnerHTML */}
        {outputHTML && (
          <div 
            id="output" 
            dangerouslySetInnerHTML={{ __html: outputHTML }}
          />
        )}

        <div id="magnifier" style={magnifierStyle}></div>
      </div>

      <footer>
        <div className="container">
          <h5>HueHub © 2024. All Rights Reserved.</h5>
        </div>
      </footer>
    </div>
  );
};

export default Home;