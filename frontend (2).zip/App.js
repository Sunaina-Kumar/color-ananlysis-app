// App.js
import React, { useState } from 'react';
import './App.css';
import { useNavigate } from 'react-router-dom';

const App = () => {
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [registerEmail, setRegisterEmail] = useState('');
  const [registerPassword, setRegisterPassword] = useState('');
  const [registerRepeatPassword, setRegisterRepeatPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState('');
  
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage('');

    if (isRegistering) {
      if (registerPassword !== registerRepeatPassword) {
        setMessage('Passwords do not match');
        setMessageType('error');
        return;
      }

      try {
        const response = await fetch('http://localhost:5000/api/register', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            email: registerEmail,
            password: registerPassword
          }),
        });

        const data = await response.json();
        setMessage(data.message);
        setMessageType(response.ok ? 'success' : 'error');

        if (response.ok) {
          setRegisterEmail('');
          setRegisterPassword('');
          setRegisterRepeatPassword('');
          setTimeout(() => {
            setIsRegistering(false);
            setMessage('');
          }, 2000);
        }
      } catch (error) {
        setMessage('Error connecting to server');
        setMessageType('error');
      }
    } else {
      try {
        const response = await fetch('http://localhost:5000/api/login', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            email: loginEmail,
            password: loginPassword
          }),
        });

        const data = await response.json();
        setMessage(data.message);
        setMessageType(response.ok ? 'success' : 'error');

        if (response.ok) {
          if (rememberMe) {
            localStorage.setItem('userEmail', loginEmail);
          }
          setLoginEmail('');
          setLoginPassword('');
          // Add delay before navigation to show success message
          setTimeout(() => {
            navigate('/home');
          }, 2000); // 2 second delay
        }
      } catch (error) {
        setMessage('Error connecting to server');
        setMessageType('error');
      }
    }
  };

  const toggleRegistration = () => {
    setIsRegistering(!isRegistering);
    setLoginEmail('');
    setLoginPassword('');
    setRegisterEmail('');
    setRegisterPassword('');
    setRegisterRepeatPassword('');
    setRememberMe(false);
    setMessage('');
  };

  return (
    <div className="wrapper">
      <form onSubmit={handleSubmit}>
        <h1><center>{isRegistering ? 'Register' : 'Login'}</center></h1>

        {message && (
          <div className={`message ${messageType}`}>
            {message}
          </div>
        )}

        <div className="input-box">
          <input
            type="email"
            placeholder={isRegistering ? 'Email' : 'Login Email'}
            value={isRegistering ? registerEmail : loginEmail}
            onChange={(e) => isRegistering ? setRegisterEmail(e.target.value) : setLoginEmail(e.target.value)}
            required
          />
          <i className="bx bxs-envelope"></i>
        </div>

        <div className="input-box">
          <input
            type="password"
            placeholder={isRegistering ? 'Set Password' : 'Login Password'}
            value={isRegistering ? registerPassword : loginPassword}
            onChange={(e) => isRegistering ? setRegisterPassword(e.target.value) : setLoginPassword(e.target.value)}
            required
          />
          <i className="bx bxs-lock-alt"></i>
        </div>

        {isRegistering && (
          <div className="input-box">
            <input
              type="password"
              placeholder="Repeat Password"
              value={registerRepeatPassword}
              onChange={(e) => setRegisterRepeatPassword(e.target.value)}
              required
            />
            <i className="bx bxs-lock-alt"></i>
          </div>
        )}

        {!isRegistering && (
          <div className="remember-forget">
            <label>
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={() => setRememberMe(!rememberMe)}
              />
              Remember me
            </label>
            <a href="#">Forgot Password?</a>
          </div>
        )}

        <button type="submit" className="btn">
          {isRegistering ? 'Register' : 'Log in'}
        </button>

        <div className="register-link">
          <p>
            {isRegistering
              ? 'Already have an account? '
              : "Don't have an account? "}
            <a href="#" onClick={toggleRegistration}>
              {isRegistering ? 'Login' : 'Register'}
            </a>
          </p>
        </div>
      </form>
    </div>
  );
};

export default App;