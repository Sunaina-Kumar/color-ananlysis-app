// colorAnalysis.js
const analyzeColors = (eyeColor, hairColor, skinColor) => {
  // Previous conversion and analysis functions remain the same
  const hexToRgb = (hex) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : null;
  };

  const getColorTemperature = (rgb) => {
    const {r, g, b} = rgb;
    return ((3 * r) + g) / ((4 * b) + g);
  };

  const getUndertone = (skinRgb) => {
    const {r, g, b} = skinRgb;
    const greenRedRatio = g / r;
    const blueRedRatio = b / r;
    const blueGreenRatio = b / g;
    
    const warmthScore = (
      (1 - greenRedRatio) * 0.5 + 
      (1 - blueRedRatio) * 0.3 + 
      (1 - blueGreenRatio) * 0.2
    );

    if (warmthScore > 0.15) return "Warm";
    if (warmthScore < -0.15) return "Cool";
    return "Neutral";
  };

  const determineSeason = (undertone, hairRgb, eyeRgb) => {
    const hairTemp = getColorTemperature(hairRgb);
    const eyeTemp = getColorTemperature(eyeRgb);
    const hairBrightness = (hairRgb.r + hairRgb.g + hairRgb.b) / 3;
    const eyeBrightness = (eyeRgb.r + eyeRgb.g + eyeRgb.b) / 3;
    const contrastLevel = Math.abs(hairBrightness - eyeBrightness) / 255;

    if (undertone === "Warm") {
      return hairTemp > 1.2 ? "Spring" : "Autumn";
    } else if (undertone === "Cool") {
      return contrastLevel > 0.4 ? "Winter" : "Summer";
    } else {
      return contrastLevel > 0.4 
        ? (hairTemp > 1.1 ? "Winter" : "Autumn")
        : (eyeTemp > 1.1 ? "Spring" : "Summer");
    }
  };

  // Main analysis
  const skinRgb = hexToRgb(skinColor);
  const hairRgb = hexToRgb(hairColor);
  const eyeRgb = hexToRgb(eyeColor);
  
  const undertone = getUndertone(skinRgb);
  const season = determineSeason(undertone, hairRgb, eyeRgb);

  const recommendations = {
    
      "Spring & Warm": {
        suitableColors: [
          { name: "Coral", hex: "#FF7F50" },
          { name: "Warm Pink", hex: "#FF69B4" },
          { name: "Golden Yellow", hex: "#FFD700" },
          { name: "Peach", hex: "#FFDAB9" },
          { name: "Bright Orange", hex: "#FFA500" },
          { name: "Warm Green", hex: "#90EE90" },
          { name: "Clear Turquoise", hex: "#40E0D0" },
          { name: "Ivory", hex: "#FFFFF0" },
          { name: "Light Camel", hex: "#C19A6B" }
        ],
        avoidColors: [
          { name: "Black", hex: "#000000" },
          { name: "Cool Gray", hex: "#708090" },
          { name: "Burgundy", hex: "#800020" },
          { name: "Dark Purple", hex: "#483D8B" },
          { name: "Navy Blue", hex: "#000080" },
          { name: "Cool Pastels", hex: "#E6E6FA" }
        ],
        jewelry: ["Yellow gold", "Rose gold", "Copper", "Coral", "Amber", "Citrine", "Peach pearls"]
      },
    
      "Autumn & Warm": {
        suitableColors: [
          { name: "Rust", hex: "#B7410E" },
          { name: "Terracotta", hex: "#E2725B" },
          { name: "Olive Green", hex: "#808000" },
          { name: "Burnt Orange", hex: "#CC5500" },
          { name: "Bronze", hex: "#CD7F32" },
          { name: "Warm Brown", hex: "#964B00" },
          { name: "Deep Gold", hex: "#FFB700" },
          { name: "Forest Green", hex: "#228B22" },
          { name: "Warm Teal", hex: "#008080" }
        ],
        avoidColors: [
          { name: "Pure White", hex: "#FFFFFF" },
          { name: "Cool Pastels", hex: "#E6E6FA" },
          { name: "Icy Blue", hex: "#B2FFFF" },
          { name: "Hot Pink", hex: "#FF69B4" },
          { name: "Electric Blue", hex: "#00FFFF" },
          { name: "Silver Gray", hex: "#C0C0C0" }
        ],
        jewelry: ["Antique gold", "Bronze", "Copper", "Tortoiseshell", "Tiger's eye", "Topaz", "Golden pearls"]
      },
    
      "Winter & Cool": {
        suitableColors: [
          { name: "Pure White", hex: "#FFFFFF" },
          { name: "True Red", hex: "#FF0000" },
          { name: "Royal Blue", hex: "#4169E1" },
          { name: "Ice Blue", hex: "#B2FFFF" },
          { name: "Emerald Green", hex: "#50C878" },
          { name: "Deep Purple", hex: "#483D8B" },
          { name: "Fuchsia Pink", hex: "#FF00FF" },
          { name: "Black", hex: "#000000" },
          { name: "Navy", hex: "#000080" }
        ],
        avoidColors: [
          { name: "Orange", hex: "#FFA500" },
          { name: "Warm Brown", hex: "#964B00" },
          { name: "Beige", hex: "#F5F5DC" },
          { name: "Mustard Yellow", hex: "#FFDB58" },
          { name: "Olive Green", hex: "#808000" }
        ],
        jewelry: ["Silver", "Platinum", "White gold", "Clear diamonds", "Sapphires", "White pearls", "Crystal"]
      },
    
      "Summer & Cool": {
        suitableColors: [
          { name: "Soft Pink", hex: "#FFB6C1" },
          { name: "Powder Blue", hex: "#B0E0E6" },
          { name: "Lavender", hex: "#E6E6FA" },
          { name: "Mauve", hex: "#E0B0FF" },
          { name: "Periwinkle", hex: "#CCCCFF" },
          { name: "Gray Blue", hex: "#6699CC" },
          { name: "Sage Green", hex: "#9DC183" },
          { name: "Cool Rose", hex: "#FF7A8C" },
          { name: "Plum", hex: "#8E4585" }
        ],
        avoidColors: [
          { name: "Orange", hex: "#FFA500" },
          { name: "Bright Yellow", hex: "#FFFF00" },
          { name: "Warm Brown", hex: "#964B00" },
          { name: "Black", hex: "#000000" },
          { name: "Neon Green", hex: "#39FF14" },
          { name: "Warm Gold", hex: "#FFD700" }
        ],
        jewelry: ["Silver", "White gold", "Pearl", "Rose quartz", "Aquamarine", "Pale blue topaz", "Pink tourmaline"]
      },
    
      "Spring & Neutral": {
        suitableColors: [
          { name: "Light Navy", hex: "#000080" },
          { name: "Warm Beige", hex: "#F5F5DC" },
          { name: "Medium Pink", hex: "#FF69B4" },
          { name: "Soft Yellow", hex: "#FFF68F" },
          { name: "Clear Green", hex: "#90EE90" },
          { name: "Light Purple", hex: "#E6E6FA" },
          { name: "Aqua", hex: "#00FFFF" },
          { name: "Neutral Brown", hex: "#964B00" },
          { name: "Cream", hex: "#FFFDD0" }
        ],
        avoidColors: [
          { name: "Pure Black", hex: "#000000" },
          { name: "Neon Pink", hex: "#FF1493" },
          { name: "Deep Burgundy", hex: "#800020" },
          { name: "Heavy Gray", hex: "#708090" }
        ],
        jewelry: ["Mixed metals", "Rose gold", "Light-toned stones", "Mixed pearls", "Clear crystals", "Moonstone", "Opal"]
      },
    
      "Summer & Neutral": {
        suitableColors: [
          { name: "Taupe", hex: "#483C32" },
          { name: "Medium Blue", hex: "#0000CD" },
          { name: "Soft Rose", hex: "#FFB6C1" },
          { name: "Gray Green", hex: "#98FF98" },
          { name: "Neutral Navy", hex: "#000080" },
          { name: "Dusty Purple", hex: "#996699" },
          { name: "Cool Beige", hex: "#F5F5DC" },
          { name: "Medium Gray", hex: "#808080" },
          { name: "Slate Blue", hex: "#6A5ACD" }
        ],
        avoidColors: [
          { name: "Bright Orange", hex: "#FFA500" },
          { name: "Strong Yellow", hex: "#FFFF00" },
          { name: "Pure Black", hex: "#000000" },
          { name: "Neon Green", hex: "#39FF14" },
          { name: "Bright Red", hex: "#FF0000" }
        ],
        jewelry: ["Mixed metals", "Pewter", "Gray pearls", "Neutral stones", "Smoky quartz", "Labradorite", "Moonstone"]
      },
    
      "Autumn & Neutral": {
        suitableColors: [
          { name: "Camel", hex: "#C19A6B" },
          { name: "Coffee Brown", hex: "#6F4E37" },
          { name: "Sage Green", hex: "#9DC183" },
          { name: "Warm Gray", hex: "#808080" },
          { name: "Medium Teal", hex: "#008080" },
          { name: "Burgundy", hex: "#800020" },
          { name: "Soft Rust", hex: "#B7410E" },
          { name: "Khaki", hex: "#C3B091" },
          { name: "Navy", hex: "#000080" }
        ],
        avoidColors: [
          { name: "Neon Pink", hex: "#FF1493" },
          { name: "Icy Blue", hex: "#B2FFFF" },
          { name: "Hot Pink", hex: "#FF69B4" },
          { name: "Electric Blue", hex: "#00FFFF" },
          { name: "Pure White", hex: "#FFFFFF" }
        ],
        jewelry: ["Mixed metals", "Oxidized silver", "Bronze", "Earth-toned stones", "Wooden jewelry", "Brown pearls", "Jasper"]
      },
    
      "Winter & Neutral": {
        suitableColors: [
          { name: "Charcoal Gray", hex: "#36454F" },
          { name: "Navy Blue", hex: "#000080" },
          { name: "Pure White", hex: "#FFFFFF" },
          { name: "Cool Red", hex: "#DC143C" },
          { name: "Dark Purple", hex: "#483D8B" },
          { name: "Forest Green", hex: "#228B22" },
          { name: "Cool Brown", hex: "#964B00" },
          { name: "Black", hex: "#000000" },
          { name: "Steel Blue", hex: "#4682B4" }
        ],
        avoidColors: [
          { name: "Warm Pastels", hex: "#FFE4E1" },
          { name: "Orange", hex: "#FFA500" },
          { name: "Warm Brown", hex: "#8B4513" },
          { name: "Light Beige", hex: "#F5F5DC" },
          { name: "Mustard Yellow", hex: "#FFDB58" }
        ],
        jewelry: ["Mixed metals", "Platinum", "Gunmetal", "Dark stones", "Black pearls", "Onyx", "Dark sapphire"]
      }
    };
  const seasonUndertone = `${season} & ${undertone}`;
  const details = recommendations[seasonUndertone] || recommendations["Spring & Warm"];

  return {
    undertone,
    season,
    description: `Your colors align with ${season} & ${undertone} characteristics, suggesting warm and bright tones suit you best.`,
    details
  };
};

export default analyzeColors;





/*const analyzeColors = (eyeColor, hairColor, skinColor) => {
  // Convert hex to RGB
  const hexToRgb = (hex) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : null;
  };

  // Calculate color temperature using a more nuanced formula
  const getColorTemperature = (rgb) => {
    const {r, g, b} = rgb;
    return ((3 * r) + g) / ((4 * b) + g);
  };

  // Improved undertone analysis with better neutral detection
  const getUndertone = (skinRgb) => {
    const {r, g, b} = skinRgb;
    
    // Calculate various color relationships
    const greenRedRatio = g / r;
    const blueRedRatio = b / r;
    const blueGreenRatio = b / g;

    // Calculate overall warmth score (-1 to 1)
    const warmthScore = (
      (1 - greenRedRatio) * 0.5 + 
      (1 - blueRedRatio) * 0.3 + 
      (1 - blueGreenRatio) * 0.2
    );

    // Define thresholds for undertone categories
    if (warmthScore > 0.15) {
      return "Warm";
    } else if (warmthScore < -0.15) {
      return "Cool";
    } else {
      return "Neutral";
    }
  };

  // Improved season determination with better handling of neutral undertones
  const determineSeason = (undertone, hairRgb, eyeRgb) => {
    const hairTemp = getColorTemperature(hairRgb);
    const eyeTemp = getColorTemperature(eyeRgb);
    const hairBrightness = (hairRgb.r + hairRgb.g + hairRgb.b) / 3;
    const eyeBrightness = (eyeRgb.r + eyeRgb.g + eyeRgb.b) / 3;
    
    // Calculate contrast level
    const contrastLevel = Math.abs(hairBrightness - eyeBrightness) / 255;

    if (undertone === "Warm") {
      return hairTemp > 1.2 ? "Spring" : "Autumn";
    } else if (undertone === "Cool") {
      return contrastLevel > 0.4 ? "Winter" : "Summer";
    } else {
      // More sophisticated neutral handling
      if (contrastLevel > 0.4) {
        return hairTemp > 1.1 ? "Winter" : "Autumn";
      } else {
        return eyeTemp > 1.1 ? "Spring" : "Summer";
      }
    }
  };

  // Enhanced color palettes
  const generatePalette = (season) => {
    const palettes = {
      Spring: ['#FF7276', '#FFB85F', '#F7E8D0', '#7ED7C1', '#E6A8D7'],
      Summer: ['#DEB0B0', '#A5B0DA', '#E6BCB0', '#B0D4B0', '#C5A5CF'],
      Autumn: ['#8B4513', '#D2691E', '#CD853F', '#DAA520', '#B8860B'],
      Winter: ['#000080', '#4B0082', '#800000', '#483D8B', '#2F4F4F']
    };
    return palettes[season];
  };

  // Main analysis
  const skinRgb = hexToRgb(skinColor);
  const hairRgb = hexToRgb(hairColor);
  const eyeRgb = hexToRgb(eyeColor);
  
  const undertone = getUndertone(skinRgb);
  const season = determineSeason(undertone, hairRgb, eyeRgb);
  const palette = generatePalette(season);

  const descriptions = {
    Spring: "Your colors are warm and bright, suggesting youthful vibrancy.",
    Summer: "Your colors are cool and muted, with a soft, romantic quality.",
    Autumn: "Your colors are warm and rich, reflecting earthly depth.",
    Winter: "Your colors are cool and intense, with dramatic contrast."
  };

  return {
    undertone,
    season,
    palette,
    description: descriptions[season]
  };
};

export default analyzeColors;

*/

