import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App.js';
import reportWebVitals from './reportWebVitals.js';
import { Route, BrowserRouter as Router, Routes } from 'react-router-dom';

// Import all components
import Home from './Home.js';
import AboutUs from './About1.js';
import FeedbackPage from './FeedbackPage.js';  // Add this import

const routing = (
  <Router>
    <div>
      <Routes>
        <Route path="/" element={<App />} />
        <Route path="/home" element={<Home />} />
        <Route path="/about" element={<AboutUs />} />
        <Route path="/feedback" element={<FeedbackPage />} />
      </Routes>
    </div>
  </Router>
);

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    {routing}
  </React.StrictMode>
);

reportWebVitals();