import React from 'react'; 
import { useNavigate } from 'react-router-dom';
import './About.css';

import SPhoto from './pfp3.jpg';
import RPhoto from './pfp2.jpg';
import SaPhoto from './pfp1.jpg';

import Step1Photo from './step1.png';
import Step2Photo from './step2.png';
import Step3Photo from './step3.png';
import Step4Photo from './step4.png';

const AboutUs = () => {
  const navigate = useNavigate();

  const founders = [
    {
      name: "name a",
      description: "A dedicated team player with a knack for organization and design,  contributed to building the Home and Feedback pages, focusing on a user-friendly experience.",
      expertise: ["Color Theory", "UX Design", "Strategy"],
      photo: RPhoto
    },
    {
      name: "name b",
      description: "A detail-oriented full-stack developer, developed the Login and About Us pages, ensuring smooth functionality and clear navigation",
      expertise: ["Algorithms", "UI Design", "Architecture"],
      photo: SPhoto
    },
    {
      name: "name c",
      description: "A creative and collaborative designer,  took charge of preparing the presentation for HueHub, highlighting the project's features and goals effectively.",
      expertise: ["PPT Design", "Accessibility", "Brand"],
      photo: SaPhoto
    }
  ];

  const handleHomeNavigation = () => {
    navigate('/home');
  };

  const handleFeedbackNavigation = () => {
    navigate('/feedback');
  };

  return (
    <div className="App">
      <header style={{
        display: 'flex', 
        flexDirection: 'column', 
        alignItems: 'center', 
        justifyContent: 'center', 
        textAlign: 'center', 
        marginBottom: '20px'
      }}>
        <div className="logo" style={{ 
          fontSize: '2rem', 
          fontWeight: 'bold', 
          marginBottom: '10px', 
          color: 'white' 
        }}>
          HueHub
        </div>
        <nav className="navbar" style={{ width: '100%', display: 'flex', justifyContent: 'center' }}>
          <ul className="nav-links" style={{ 
            display: 'flex', 
            gap: '20px', 
            justifyContent: 'center', 
            listStyle: 'none', 
            padding: 0 
          }}>
            <li><a onClick={handleHomeNavigation} className="nav-link" style={{cursor: 'pointer'}}>Home</a></li>
            <li><a href="#" className="nav-link active">About Us</a></li>
            <li><a onClick={handleFeedbackNavigation} className="nav-link" style={{cursor: 'pointer'}}>Feedback</a></li>
          </ul>
        </nav>
      </header>

      <div className="wrapper">
        <h1><center>Meet Our Team</center></h1>
        <p style={{ textAlign: 'center', marginBottom: '3rem', color: 'white' }}>
          The creative minds behind HueHub
        </p>

        <div style={{ 
          display: 'flex', 
          gap: '20px',
          justifyContent: 'center',
          alignItems: 'stretch'
        }}>
          {founders.map((founder, index) => (
            <div key={index} className="card" style={{
              flex: '1',
              background: 'transparent',
              backdropFilter: 'blur(2px)',
              borderRadius: '10px',
              padding: '20px',
              boxShadow: '0 0 15px rgba(138, 43, 226, 0.5)',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center'
            }}>
              <div style={{
                width: '160px',
                height: '160px',
                borderRadius: '50%',
                overflow: 'hidden',
                marginBottom: '1rem',
                border: '2px solid rgba(255, 255, 255, 0.2)'
              }}>
                <img 
                  src={founder.photo}
                  alt={founder.name}
                  style={{
                    width: '100%',
                    height: '100%',
                    objectFit: 'cover'
                  }}
                />
              </div>

              <h2 style={{
                fontSize: '1.5rem',
                fontWeight: '600',
                marginBottom: '0.5rem',
                color: 'white'
              }}>{founder.name}</h2>

              <p style={{
                fontSize: '0.9rem',
                marginBottom: '1rem',
                textAlign: 'center',
                color: 'white'
              }}>{founder.description}</p>

              <div style={{
                display: 'flex',
                flexWrap: 'wrap',
                gap: '8px',
                justifyContent: 'center'
              }}>
                {founder.expertise.map((skill, skillIndex) => (
                  <span key={skillIndex} style={{
                    background: 'rgba(255, 255, 255, 0.2)',
                    padding: '5px 12px',
                    borderRadius: '20px',
                    fontSize: '0.8rem',
                    color: 'white'
                  }}>
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
        
        <h1 style={{ textAlign: 'center', margin: '3rem 0 1rem', color: 'white' }}><center>How It Works</center></h1>

        <div className="steps-container">
          <div className="step card">
            <img src={Step1Photo} alt="Step 1" className="step-image" />
            <div>
              <h3>Step 1: Upload Photo</h3>
              <p>Upload a photo of yourself to get started.</p>
            </div>
          </div>
          <div className="step card">
            <img src={Step2Photo} alt="Step 2" className="step-image" />
            <div>
              <h3>Step 2: Pick Hair, Eye, and Skin Color</h3>
              <p>Select your hair, eye, and skin color to customize your palette.</p>
            </div>
          </div>
          <div className="step card">
            <img src={Step3Photo} alt="Step 3" className="step-image" />
            <div>
              <h3>Step 3: Hit the Analyze Button</h3>
              <p>Click the analyze button to process your information.</p>
            </div>
          </div>
          <div className="step card">
            <img src={Step4Photo} alt="Step 4" className="step-image" />
            <div>
              <h3>Step 4: Check Your Results</h3>
              <p>Review the analysis results to see your customized palette along with jewellery recommendations.</p>
            </div>
          </div>
        </div>
      </div>

      <footer>
        <div className="container">
          <h5>HueHub © 2024. All Rights Reserved.</h5>
        </div>
      </footer>
    </div>
  );
};

export default AboutUs;